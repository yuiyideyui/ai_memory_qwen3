# memory_manager.py
from zoneinfo import ZoneInfo
import chromadb
from chromadb.config import Settings
from config import CHROMA_DB_DIR
import uuid
from datetime import datetime, timezone, timedelta
import re
# room_manager.py
import os
import json
from typing import List, Dict, Optional
# memory_manager.py
from chromadb import Client
# -----------------------
# 初始化 ChromaDB 客户端
# -----------------------
# ✅ 仅初始化一次，确保设置一致
client = chromadb.PersistentClient(
    path=CHROMA_DB_DIR,
    settings=Settings(allow_reset=True)  # ✅ 保持与所有地方一致
)

# 🔥 时区处理 - 兼容性更好的方式
def get_china_timezone():
    """获取中国时区，兼容不同环境"""
    try:
        # 尝试使用 zoneinfo（Python 3.9+）
        from zoneinfo import ZoneInfo
        return ZoneInfo("Asia/Shanghai")
    except ImportError:
        try:
            # 尝试使用 pytz
            import pytz
            return pytz.timezone('Asia/Shanghai')
        except ImportError:
            # 回退到 UTC 并打印警告
            print("警告: 无法找到 Asia/Shanghai 时区，使用 UTC 时区")
            return timezone.utc

# 获取时区对象
CHINA_TZ = get_china_timezone()
# -----------------------
# 工具函数
# -----------------------
def sanitize_name(name: str) -> str:
    """
    将任意字符串转换为符合 ChromaDB collection 名称规范
    """
    sanitized = re.sub(r"[^a-zA-Z0-9._-]", "_", name)
    sanitized = re.sub(r"^[^a-zA-Z0-9]+", "", sanitized)
    sanitized = re.sub(r"[^a-zA-Z0-9]+$", "", sanitized)
    while len(sanitized) < 3:
        sanitized += "_"
    return sanitized

# -----------------------
# Collection 管理
# -----------------------
def list_roles() -> List[str]:
    print( "Existing collections:", client.list_collections())  # 调试输出
    return [col.name for col in client.list_collections()]

def get_or_create_collection(role: str):
    role_safe = sanitize_name(role)
    existing = [c.name for c in client.list_collections()]
    print('Creating collection:', role_safe,client.list_collections())  # 调试输出
    if role_safe not in existing:
        
        return client.create_collection(name=role_safe)
    return client.get_collection(name=role_safe)

# -----------------------
# 添加记忆
# -----------------------

from config import START_TIME
# 在 memory_manager.py 中添加

class MemoryManager:
    def __init__(self):
        self.short_term_threshold = 5  # 短期记忆数量阈值
        self.importance_scores = {}    # 记忆重要性评分
        
    def calculate_importance(self, content: str, mem_type: str, role: str) -> float:
        """计算记忆重要性分数"""
        score = 1.0
        
        # 类型权重
        type_weights = {
            "system": 10.0,    # 系统指令最重要
            "emotion": 8.0,    # 情感记忆
            "conversation": 3.0, # 对话记忆
            "hearing": 2.0,    # 听到的内容
            "response": 2.0,   # 自己的回应
            "note": 1.0        # 普通笔记
        }
        score *= type_weights.get(mem_type, 1.0)
        
        # 内容特征
        if "重要" in content or "关键" in content or "记住" in content:
            score *= 2.0
        if len(content) > 50:  # 较长内容可能更重要
            score *= 1.5
        if "?" in content:     # 问题可能更重要
            score *= 1.3
            
        return score

# 全局记忆管理器
memory_manager = MemoryManager()

def add_memory(role: str, content: str, mtype: str = "note") -> None:
    try:
        memory_id = str(uuid.uuid4())
        current_time = datetime.now(CHINA_TZ)
        virtual_time_seconds = (current_time - START_TIME).total_seconds() * 20
        virtual_time = START_TIME + timedelta(seconds=virtual_time_seconds)
        timestamp = virtual_time.isoformat()

        importance = memory_manager.calculate_importance(content, mtype, role)
        
        collection = get_or_create_collection(role)
        collection.add(
            ids=[memory_id],
            documents=[content],
            metadatas=[{
                "type": mtype, 
                "created_at": timestamp,
                "importance": importance,
                "access_count": 0
            }]
        )
        
        print(f"添加记忆: [{mtype}] 重要性:{importance:.1f} - {content[:30]}...")

    except Exception as e:
        print(f"Error adding memory: {e}")

# -----------------------
# 休息状态管理
# -----------------------
class RestStateManager:
    def __init__(self):
        self.rest_states = {}
    
    def set_rest_state(self, role: str, is_resting: bool, rest_type: str = "sleep"):
        if is_resting:
            current_time = datetime.now(CHINA_TZ)
            self.rest_states[role] = {
                "is_resting": True,
                "rest_start_time": current_time.isoformat(),
                "rest_type": rest_type
            }
            print(f"角色 {role} 进入{rest_type}状态")
        else:
            if role in self.rest_states:
                del self.rest_states[role]
            print(f"角色 {role} 结束休息状态")
    
    def is_resting(self, role: str) -> bool:
        return self.rest_states.get(role, {}).get("is_resting", False)
    
    def get_rest_info(self, role: str) -> dict:
        return self.rest_states.get(role, {
            "is_resting": False,
            "rest_start_time": None,
            "rest_type": None
        })

rest_manager = RestStateManager()

def check_rest_state(role: str, current_time: datetime) -> dict:
    """AI决定角色是否应该休息"""
    try:
        # 简单基于时间的决策（可以扩展为AI决策）
        hour = current_time.hour
        
        # 夜间睡眠时间（22:00-6:00）
        if 22 <= hour or hour <= 6:
            return {"should_rest": True, "rest_type": "sleep", "reason": "夜间休息时间"}
        # 午休时间（13:00-14:00）
        elif 13 <= hour <= 14:
            return {"should_rest": True, "rest_type": "nap", "reason": "午休时间"}
        else:
            return {"should_rest": False, "rest_type": None, "reason": "活动时间"}
                
    except Exception as e:
        print(f"检查角色 {role} 休息状态失败: {e}")
        return {"should_rest": False, "rest_type": None, "reason": "检查失败"}

def update_rest_states():
    """更新所有角色的休息状态"""
    try:
        current_time = datetime.now(CHINA_TZ)
        roles = list_roles()
        
        for role in roles:
            decision = check_rest_state(role, current_time)
            
            if decision["should_rest"]:
                rest_manager.set_rest_state(role, True, decision["rest_type"])
            else:
                if rest_manager.is_resting(role):
                    rest_manager.set_rest_state(role, False)
                    
    except Exception as e:
        print(f"更新休息状态失败: {e}")

def query_memory(role: str, query: str, top_k: int = 100000) -> List[Dict]:
    """获取所有记忆，兼容旧版本 ChromaDB"""
    role_safe = sanitize_name(role)
    existing = [c.name for c in client.list_collections()]
    if role_safe not in existing:
        return []

    collection = client.get_collection(name=role_safe)

    try:
        # 🔥 使用 get() 方法获取所有记忆（更兼容）
        # 先获取总数
        count_result = collection.count()
        total_count = count_result if isinstance(count_result, int) else count_result.get('count', 0)
        
        print(f"角色 {role} 共有 {total_count} 条记忆")
        
        if total_count == 0:
            return []
        
        # 使用 get() 获取所有记录（更可靠）
        all_results = collection.get(
            include=["documents", "metadatas"],
            limit=min(total_count, 100000)  # 限制最大获取数量
        )
        
        documents = all_results.get("documents", [])
        metadatas = all_results.get("metadatas", [])
        ids = all_results.get("ids", [])
        
        print(f"实际获取了 {len(documents)} 条记忆")
        
        # 处理记忆数据
        min_length = min(len(documents), len(metadatas), len(ids))
        
        mems = []
        for i in range(min_length):
            metadata = metadatas[i] if metadatas[i] else {
                "type": "note", 
                "created_at": "1970-01-01T00:00:00",
                "importance": 1.0,
                "access_count": 0
            }
            mems.append({
                "id": ids[i] if i < len(ids) else str(i),
                "content": documents[i],
                "metadata": metadata
            })
        
        # 更新访问计数（模拟记忆强化）
        for mem in mems:
            if "access_count" not in mem["metadata"]:
                mem["metadata"]["access_count"] = 0
            mem["metadata"]["access_count"] += 1
            
            # 更新访问计数到数据库
            try:
                collection.update(
                    ids=[mem.get("id", str(uuid.uuid4()))],
                    metadatas=[mem["metadata"]]
                )
            except Exception as e:
                print(f"更新访问计数失败: {e}")
        
        # 🔥 智能回忆算法
        recall_memories = []
        
        # 1. 系统身份记忆（最高优先级）
        system_mems = [mem for mem in mems if mem["metadata"].get("type") in ["system", "role_setup", "note"]]
        recall_memories.extend(system_mems)
        
        # 2. 时间记忆（重要背景信息）
        time_mems = [mem for mem in mems if mem["metadata"].get("type") == "time"]
        # 取最新的时间记忆
        if time_mems:
            latest_time_mem = sorted(time_mems, 
                                   key=lambda x: x["metadata"].get("created_at", "1970-01-01T00:00:00"))[-1]
            recall_memories.append(latest_time_mem)
        
        # 3. 高重要性记忆
        important_mems = [mem for mem in mems 
                         if mem["metadata"].get("importance", 1.0) > 5.0 
                         and mem["metadata"].get("type") not in ["system", "role_setup", "note", "time"]]
        recall_memories.extend(important_mems)
        
        # 4. 频繁访问记忆
        frequent_mems = [mem for mem in mems 
                        if mem["metadata"].get("access_count", 0) > 3
                        and mem["metadata"].get("type") not in ["system", "role_setup", "note", "time"]]
        recall_memories.extend(frequent_mems)
        
        # 5. 最近记忆（短期记忆）
        other_mems = [mem for mem in mems 
                     if mem not in recall_memories]  # 排除已选记忆
        recent_mems = sorted(other_mems, 
                           key=lambda x: x["metadata"].get("created_at", "1970-01-01T00:00:00"))[-8:]
        recall_memories.extend(recent_mems)
        
        # 去重（基于内容）
        unique_mems = {}
        for mem in recall_memories:
            key = mem["content"][:100]  # 基于内容去重
            if key not in unique_mems:
                unique_mems[key] = mem
        
        final_mems = list(unique_mems.values())
        
        # 按综合得分排序
        def memory_score(mem):
            importance = mem["metadata"].get("importance", 1.0)
            access_count = mem["metadata"].get("access_count", 0)
            create_time = mem["metadata"].get("created_at", "1970-01-01T00:00:00")
            time_factor = 1.0 if "1970" in create_time else 2.0
            
            # 时间记忆的特殊权重
            if mem["metadata"].get("type") == "time":
                importance *= 3.0
            
            return importance * (1 + access_count * 0.5) * time_factor
        
        final_mems.sort(key=memory_score, reverse=True)
        
        print(f"角色 {role} 智能回忆: {len(final_mems)} 条记忆（总数: {len(mems)}）")
        for i, mem in enumerate(final_mems[:5]):  # 只显示前5条
            importance = mem["metadata"].get("importance", 1.0)
            access_count = mem["metadata"].get("access_count", 0)
            mem_type = mem["metadata"].get("type", "unknown")
            print(f"  {i+1}. [{mem_type}] 重要性:{importance:.1f} 访问:{access_count} - {mem['content'][:50]}...")
        
        return final_mems
        
    except Exception as e:
        print(f"查询记忆失败: {e}")
        import traceback
        traceback.print_exc()
        return []


def delete_collection(role: str) -> bool:
    """删除指定角色的记忆 collection"""
    try:
        role_safe = sanitize_name(role)
        # 检查集合是否存在
        existing_collections = [c.name for c in client.list_collections()]
        if role_safe in existing_collections:
            client.delete_collection(name=role_safe)
            return True
        else:
            # 集合不存在，也算删除成功（幂等操作）
            return True
    except Exception as e:
        print(f"删除角色 {role} 记忆失败: {e}")
        return False



def delete_all_collections():
    """删除所有角色的记忆 collection"""
    try:
        # 使用全局的 client 实例
        collections = client.list_collections()
        for col in collections:
            # ✅ 删除整个集合
            client.delete_collection(name=col.name)
        return True
    except Exception as e:
        # 捕获所有异常并记录详细信息
        print(f"删除所有集合失败: {e}")
        return False


# 在 memory_manager.py 中添加
def update_time_memory(role: str, current_time_info: dict):
    """更新时间记忆（修改或创建唯一的时间记忆）"""
    try:
        # 🔥 使用中国时区
        current_time = datetime.now(CHINA_TZ)
        virtual_time_seconds = (current_time - START_TIME).total_seconds() * 20
        virtual_time = START_TIME + timedelta(seconds=virtual_time_seconds)
        timestamp = virtual_time.isoformat()
        
        # 格式化时间记忆内容
        time_memory_content = f"当前时间：{timestamp}。"
        
        role_safe = sanitize_name(role)
        collection = get_or_create_collection(role_safe)
        
        # 查找现有的时间记忆
        existing_memories = collection.peek(limit=1000)
        documents = existing_memories.get("documents", [])
        metadatas = existing_memories.get("metadatas", [])
        ids = existing_memories.get("ids", [])
        
        time_memory_id = None
        
        # 查找时间记忆（类型为"time"）
        for i, metadata in enumerate(metadatas):
            if i < len(ids) and metadata and metadata.get("type") == "time":
                time_memory_id = ids[i]
                break
        
        if time_memory_id:
            # 更新时间记忆
            collection.update(
                ids=[time_memory_id],
                documents=[time_memory_content],
                metadatas=[{
                    "type": "time", 
                    "created_at": timestamp,
                    "importance": 8.0,
                    "access_count": 0
                }]
            )
            print(f"更新时间记忆 - 角色 {role}: {timestamp}")
        else:
            # 创建新的时间记忆
            memory_id = str(uuid.uuid4())
            collection.add(
                ids=[memory_id],
                documents=[time_memory_content],
                metadatas=[{
                    "type": "time", 
                    "created_at": timestamp,
                    "importance": 8.0,
                    "access_count": 0
                }]
            )
            print(f"创建时间记忆 - 角色 {role}: {timestamp}")
        
    except Exception as e:
        print(f"更新时间记忆失败: {e}")


def get_latest_time_memory(role: str) -> Optional[Dict]:
    """获取角色的最新时间记忆"""
    try:
        role_safe = sanitize_name(role)
        existing = [c.name for c in client.list_collections()]
        if role_safe not in existing:
            return None
            
        collection = client.get_collection(name=role_safe)
        memories = collection.peek(limit=1000)
        
        documents = memories.get("documents", [])
        metadatas = memories.get("metadatas", [])
        
        time_memories = []
        for i, metadata in enumerate(metadatas):
            if i < len(documents) and metadata and metadata.get("type") == "time":
                time_memories.append({
                    "content": documents[i],
                    "metadata": metadata
                })
        
        if time_memories:
            # 返回最新的时间记忆
            latest = sorted(time_memories, 
                          key=lambda x: x["metadata"].get("created_at", "1970-01-01T00:00:00"))[-1]
            return latest
        
        return None
        
    except Exception as e:
        print(f"获取时间记忆失败: {e}")
        return None



ROOM_FILE = "data/room.json"
ROOMS_DIR = "data/rooms"

# 确保目录存在
os.makedirs(ROOMS_DIR, exist_ok=True)

class Room:
    def __init__(self, name: str = "客厅", width: int = 800, height: int = 600):
        self.name = name
        self.width = width
        self.height = height
        self.roles: List[Dict] = []
    
    def add_role(self, role_name: str, x: int, y: int, avatar: str = "👤"):
        # 检查角色是否已存在
        for role in self.roles:
            if role["name"] == role_name:
                role["x"] = x
                role["y"] = y
                role["avatar"] = avatar
                return
        
        # 添加新角色
        self.roles.append({
            "name": role_name,
            "x": x,
            "y": y,
            "avatar": avatar
        })
    
    def remove_role(self, role_name: str):
        self.roles = [r for r in self.roles if r["name"] != role_name]
    
    def get_role(self, role_name: str) -> Optional[Dict]:
        for role in self.roles:
            if role["name"] == role_name:
                return role
        return None
    
    def to_dict(self):
        return {
            "name": self.name,
            "width": self.width,
            "height": self.height,
            "roles": self.roles
        }
    # 在 room_manager.py 中添加以下方法到 Room 类

    def calculate_distance(self, x1: int, y1: int, x2: int, y2: int) -> float:
        """计算两点间距离"""
        return ((x1 - x2) ** 2 + (y1 - y2) ** 2) ** 0.5

    def get_nearby_roles(self, user_x: int, user_y: int, max_distance: int = 300) -> List[Dict]:
        """获取附近的角色"""
        nearby_roles = []
        for role in self.roles:
            distance = self.calculate_distance(user_x, user_y, role["x"], role["y"])
            if distance <= max_distance:
                nearby_roles.append({
                    "role": role,
                    "distance": distance
                })
        return nearby_roles

    def get_roles_by_distance_tiers(self, user_x: int, user_y: int) -> Dict[str, List]:
        """按距离分级获取角色"""
        nearby_roles = self.get_nearby_roles(user_x, user_y, 500)  # 500像素范围内的角色
        
        # 按距离分级
        very_close = []    # 0-100像素：近距离，完整消息
        close = []         # 100-250像素：中距离，部分消息
        far = []           # 250-500像素：远距离，少量消息
        
        for role_info in nearby_roles:
            role = role_info["role"]
            distance = role_info["distance"]
            
            if distance <= 100:
                very_close.append(role)
            elif distance <= 250:
                close.append(role)
            elif distance <= 500:
                far.append(role)
        
        return {
            "very_close": very_close,    # 能清楚听到
            "close": close,              # 能模糊听到
            "far": far                   # 只能偶尔听到
        }

    @classmethod
    def from_dict(cls, data: Dict):
        room = cls(data.get("name", "客厅"), data.get("width", 800), data.get("height", 600))
        room.roles = data.get("roles", [])
        return room

def get_room_file_path(room_name: str = "main") -> str:
    """获取房间文件路径"""
    return os.path.join(ROOMS_DIR, f"{room_name}.json")

def init_room(room_name: str = "main"):
    """初始化房间"""
    room_file = get_room_file_path(room_name)
    if not os.path.exists(room_file):
        room = Room()
        save_room(room, room_name)

def get_room(room_name: str = "main") -> Room:
    """获取房间对象"""
    init_room(room_name)
    room_file = get_room_file_path(room_name)
    
    try:
        with open(room_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        return Room.from_dict(data)
    except Exception as e:
        print(f"读取房间数据失败: {e}")
        return Room()

def save_room(room: Room, room_name: str = "main"):
    """保存房间对象"""
    room_file = get_room_file_path(room_name)
    try:
        with open(room_file, "w", encoding="utf-8") as f:
            json.dump(room.to_dict(), f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"保存房间数据失败: {e}")

def add_role_to_room(role_name: str, x: int, y: int, room_name: str = "main", avatar: str = "👤"):
    """添加或更新角色位置"""
    room = get_room(room_name)
    room.add_role(role_name, x, y, avatar)
    save_room(room, room_name)

def remove_role_from_room(role_name: str, room_name: str = "main"):
    """从房间移除角色"""
    room = get_room(room_name)
    room.remove_role(role_name)
    save_room(room, room_name)

def get_role_position(role_name: str, room_name: str = "main") -> Optional[Dict]:
    """获取角色位置"""
    room = get_room(room_name)
    return room.get_role(role_name)

def clear_room(room_name: str = "main"):
    """清空房间"""
    room = Room()
    save_room(room, room_name)

def list_rooms() -> List[str]:
    """列出所有房间"""
    try:
        files = os.listdir(ROOMS_DIR)
        return [f.replace(".json", "") for f in files if f.endswith(".json")]
    except:
        return []

def delete_room(room_name: str):
    """删除房间"""
    room_file = get_room_file_path(room_name)
    if os.path.exists(room_file):
        os.remove(room_file)
