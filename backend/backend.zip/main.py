# main.py
import uvicorn
import socketio
from app import app, sio

# 创建 SocketIO ASGI 应用
sio_app = socketio.ASGIApp(sio, other_asgi_app=app, socketio_path="/socket.io/")

if __name__ == "__main__":
    uvicorn.run(sio_app, host="127.0.0.1", port=8000, log_level="info")