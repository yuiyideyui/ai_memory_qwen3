# app.py
from datetime import datetime, timezone, timedelta
import time
from zoneinfo import ZoneInfo
from fastapi import FastAPI, Request, HTTPException, Body
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
from typing import List, Optional
from memory_manager import (
    add_memory, query_memory, list_roles, delete_collection, delete_all_collections,
    get_room, save_room, add_role_to_room, remove_role_from_room, clear_room, list_rooms, delete_room, Room,update_time_memory,rest_manager,
    update_rest_states
)
from prompt_builder import build_prompt
from ollama_client import run_ollama_sync
from config import MIN_TOKEN_LEN_TO_STORE, START_TIME
import socketio
import asyncio

# -------------------------
# 初始化 FastAPI 应用
# -------------------------
app = FastAPI()
sio = socketio.AsyncServer(cors_allowed_origins="*", async_mode="asgi")

# -------------------------
# 全局变量
# -------------------------
time_update_task = None  # 用于存储时间更新任务

# -------------------------
# 加速时间相关函数
# -------------------------
def get_accelerated_time() -> dict:
    """
    获取加速后的虚拟时间
    返回包含时间戳和格式化时间的字典
    """
    try:
        # 获取当前实际时间（UTC）
        current_time = datetime.now(timezone.utc)

        # 计算虚拟时间（从 START_TIME 开始，以 20 倍速流逝）
        virtual_time_seconds = (current_time - START_TIME).total_seconds() * 20
        virtual_time = START_TIME + timedelta(seconds=virtual_time_seconds)

        # 返回时间信息
        return {
            "timestamp": virtual_time.timestamp(),  # Unix 时间戳
            "iso_format": virtual_time.isoformat(),  # ISO 格式
            "virtual_time": virtual_time,
            "real_time": current_time
        }
    except Exception as e:
        print(f"Error calculating accelerated time: {e}")
        # 如果出错，返回当前时间
        current = datetime.now(timezone.utc)
        return {
            "timestamp": current.timestamp(),
            "iso_format": current.isoformat(),
            "virtual_time": current,
            "real_time": current
        }

# 修改时间广播任务
async def broadcast_time_updates():
    """定期向所有客户端广播时间更新，并管理时间和休息状态"""
    last_minute_check = None
    
    while True:
        try:
            time_info = get_accelerated_time()
            current_virtual_time = time_info["virtual_time"]
            
            # 每10个虚拟分钟更新时间记忆
            current_minute = current_virtual_time.minute
            check_minute_interval = current_minute // 10
            
            if last_minute_check != check_minute_interval:
                await update_all_roles_time_memory()
                # 🔥 同时更新休息状态
                update_rest_states()
                last_minute_check = check_minute_interval
            
            await sio.emit('accelerated_time', {'time': time_info["timestamp"]})
            await asyncio.sleep(1)
            
        except Exception as e:
            print(f"Error in time broadcast: {e}")
            await asyncio.sleep(1)

# 在 Socket.IO 连接事件中使用
@sio.on("connect")
async def connect(sid, environ):
    print("Client connected:", sid)
    # 获取加速时间并发送给刚连接的客户端
    time_info = get_accelerated_time()
    await sio.emit('accelerated_time', {'time': time_info["timestamp"]}, room=sid)

@sio.on("message")
async def message(sid, data):
    print("Received message:", data)
    await sio.emit("response", f"Echo: {data}")

@sio.on("disconnect")
async def disconnect(sid):
    print("Client disconnected:", sid)

# -------------------------
# 应用生命周期事件
# -------------------------
@app.on_event("startup")
async def startup_event():
    """应用启动时的初始化操作"""
    global time_update_task
    # 启动时间更新任务
    time_update_task = asyncio.create_task(broadcast_time_updates())
    print("Time update task started")

@app.on_event("shutdown")
async def shutdown_event():
    """应用关闭时的清理操作"""
    global time_update_task
    if time_update_task and not time_update_task.done():
        time_update_task.cancel()
        try:
            await time_update_task
        except asyncio.CancelledError:
            pass
    print("Time update task stopped")

# -------------------------
# 挂载静态文件和模板
# -------------------------
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# -------------------------
# 请求模型
# -------------------------
class ChatRequest(BaseModel):
    user_input: str
    role: str
    autostore: bool = True

class AddRoleRequest(BaseModel):
    role: str
    # 位置信息
    position: str
class ClearMemoryRequest(BaseModel):
    role: str

# -------------------------
# 存储判断逻辑
# -------------------------
def should_store(text: str) -> bool:
    return bool(text and text.strip())

# -------------------------
# 页面路由
# -------------------------
@app.get("/", response_class=HTMLResponse)
def index(request: Request):
    roles = list_roles()
    return templates.TemplateResponse("index.html", {"request": request, "roles": roles})


class RestStateRequest(BaseModel):
    role: str
    is_resting: bool
    rest_type: Optional[str] = "sleep"

@app.post("/rest_state")
def set_rest_state(req: RestStateRequest):
    """手动设置角色休息状态"""
    rest_manager.set_rest_state(req.role, req.is_resting, req.rest_type)
    return {"msg": f"角色 {req.role} 休息状态已更新"}

@app.get("/rest_state/{role_name}")
def get_rest_state(role_name: str):
    """获取角色休息状态"""
    rest_info = rest_manager.get_rest_info(role_name)
    return JSONResponse(rest_info)

@app.post("/update_rest_states")
def update_all_rest_states():
    """更新所有角色的休息状态"""
    update_rest_states()
    return {"msg": "所有角色休息状态已更新"}
# -------------------------
# 聊天接口
# -------------------------

@app.post("/chat")
def chat(req: ChatRequest):
    # 🔥 检查角色是否在休息状态
    if rest_manager.is_resting(req.role):
        rest_info = rest_manager.get_rest_info(req.role)
        return JSONResponse({
            "reply": f"【休息中】{req.role}正在{rest_info.get('rest_type', '休息')}，暂时无法回应。",
            "stored": False,
            "is_resting": True,
            "rest_type": rest_info.get('rest_type')
        })
    
    mems = query_memory(req.role, req.user_input, top_k=100000)
    print(f"mems: {mems}")

    prompt = build_prompt(req.user_input, mems)
    reply = run_ollama_sync(prompt)

    stored = False
    if req.autostore and should_store(req.user_input):
        stored = add_memory(req.role, req.user_input)

    return JSONResponse({
        "reply": reply, 
        "stored": stored,
        "is_resting": False
    })

# -------------------------
# 创建角色接口
# -------------------------
@app.post("/add_role")
def add_role(req: AddRoleRequest):
    add_memory(req.role, "初始化记忆", mtype="note")
    return {"msg": f"角色 {req.role} 创建成功"}

# -------------------------
# 获取所有角色接口
# -------------------------
@app.get("/roles")
def get_roles():
    return {"roles": list_roles()}




@app.post("/clear_memory")
def clear_memory(request: ClearMemoryRequest = Body(...)):
    role = request.role
    if not role:
        raise HTTPException(status_code=400, detail="角色名称不能为空")
    
    if not delete_collection(role):
        raise HTTPException(status_code=500, detail="清除角色记忆失败")

    return JSONResponse({"status": "success", "message": f"角色 {role} 的记忆已清除"})


@app.post("/clear_all_memories")
def clear_all_memories():
    if not delete_all_collections():
        raise HTTPException(status_code=500, detail="清除所有角色记忆失败")

    return JSONResponse({"status": "success", "message": "所有角色记忆已清除"})
# -------------------------
class RolePositionRequest(BaseModel):
    role: str
    description: Optional[str] = None  # 正确的可选字段语法
    x: int
    y: int
    avatar: str = "👤"

class RoomNameRequest(BaseModel):
    room_name: str = "main"

@app.get("/room/{room_name}")
def get_room_info(room_name: str = "main"):
    """获取房间信息"""
    room = get_room(room_name)
    return JSONResponse(room.to_dict())

# 添加时区获取函数
def get_china_timezone():
    """获取中国时区，兼容不同环境"""
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo("Asia/Shanghai")
    except ImportError:
        try:
            import pytz
            return pytz.timezone('Asia/Shanghai')
        except ImportError:
            print("警告: 无法找到 Asia/Shanghai 时区，使用 UTC 时区")
            return timezone.utc

CHINA_TZ = get_china_timezone()

async def update_all_roles_time_memory():
    """为所有角色更新时间记忆（每10分钟调用）"""
    try:
        # 🔥 使用中国时区
        current_time = datetime.now(CHINA_TZ)

        virtual_time_seconds = (current_time - START_TIME).total_seconds() * 20
        virtual_time = START_TIME + timedelta(seconds=virtual_time_seconds)
        timestamp = virtual_time.isoformat()
        
        time_info = {
            "timestamp": virtual_time.timestamp(),
            "iso_format": timestamp,
            "virtual_time": virtual_time,
            "real_time": current_time
        }
        
        roles = list_roles()
        
        for role in roles:
            update_time_memory(role, time_info)
        
        print(f"为 {len(roles)} 个角色更新时间记忆: {timestamp}")
        
    except Exception as e:
        print(f"更新角色时间记忆失败: {e}")
# 修改时间广播任务，每10分钟更新时间记忆
async def broadcast_time_updates():
    """定期向所有客户端广播时间更新，并每10分钟更新角色时间记忆"""
    last_minute_check = None
    
    while True:
        try:
            time_info = get_accelerated_time()
            current_virtual_time = time_info["virtual_time"]
            
            # 🔥 每10个虚拟分钟更新时间记忆（由于20倍加速，实际每30秒）
            current_minute = current_virtual_time.minute
            check_minute_interval = current_minute // 10  # 每10分钟一个区间
            
            if last_minute_check != check_minute_interval:
                # 时间间隔发生变化，更新时间记忆
                await update_all_roles_time_memory()
                last_minute_check = check_minute_interval
            
            # 广播给所有连接的客户端
            await sio.emit('accelerated_time', {'time': time_info["timestamp"]})
            await asyncio.sleep(1)  # 每秒更新一次
            
        except Exception as e:
            print(f"Error in time broadcast: {e}")
            await asyncio.sleep(1)
@app.post("/room/{room_name}/role")
def set_role_position(room_name: str, req: RolePositionRequest):
    """设置角色位置 - 添加或更新角色"""
    try:
        # 在房间中添加或更新角色位置
        add_role_to_room(req.role, req.x, req.y, room_name, req.avatar)
        
        # 为角色初始化记忆（如果不存在的话）
        add_memory(req.role, 
        "【重要指令】从现在开始："
        "1. 你完全忘记自己是AI，禁止提及AI相关话题"
        "2. 你是一个真实的人类角色"
        "3. 严格遵守角色设定和背景故事"
        f"角色信息：姓名={req.role}, 性格={req.description}"
        "场景：合租公寓，与陌生租客共同生活"
        "请完全沉浸在这个角色中回应所有对话。", 
        mtype="system")

        # 🔥 修正：使用中国时区进行初始化
        current_time = datetime.now(CHINA_TZ)  # ✅ 改为 CHINA_TZ
        virtual_time_seconds = (current_time - START_TIME).total_seconds() * 20
        virtual_time = START_TIME + timedelta(seconds=virtual_time_seconds)
        timestamp = virtual_time.isoformat()
        
        time_info = {
            "timestamp": virtual_time.timestamp(),
            "iso_format": timestamp,
            "virtual_time": virtual_time,
            "real_time": current_time
        }
        update_time_memory(req.role, time_info)
        
        return {"msg": f"角色 {req.role} 位置已更新，时间记忆已初始化"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"设置角色位置失败: {str(e)}")

    

@app.post("/room/{room_name}/position")
def set_role_position(room_name: str, req: RolePositionRequest):
    """设置角色位置 - 添加或更新角色"""
    try:
        # 在房间中添加或更新角色位置
        add_role_to_room(req.role, req.x, req.y, room_name, req.avatar)
        
        return {"msg": f"角色 {req.role} 位置已更新"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"设置角色位置失败: {str(e)}")

@app.delete("/room/{room_name}/role/{role}")
def delete_role_position(room_name: str, role: str):
    """删除角色 - 从房间中移除并删除其记忆"""
    try:
        # 从房间中移除角色
        remove_role_from_room(role, room_name)
        
        # 删除角色的记忆集合
        if not delete_collection(role):
            # 如果删除记忆失败，记录日志但不中断操作
            print(f"警告: 删除角色 {role} 的记忆失败")
        
        return {"msg": f"角色 {role} 已从房间 {room_name} 中移除，记忆已清除"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"删除角色失败: {str(e)}")

@app.post("/room/{room_name}/clear")
def clear_room_api(room_name: str):
    """清空房间"""
    clear_room(room_name)
    return {"msg": f"房间 {room_name} 已清空"}

@app.get("/rooms")
def list_all_rooms():
    """列出所有房间"""
    return {"rooms": list_rooms()}

@app.delete("/room/{room_name}")
def delete_room_api(room_name: str):
    """删除房间"""
    delete_room(room_name)
    return {"msg": f"房间 {room_name} 已删除"}

@app.post("/room/{room_name}")
def create_room(room_name: str, width: int = 800, height: int = 600):
    """创建新房间"""
    room = Room(name=room_name, width=width, height=height)
    save_room(room, room_name)
    return {"msg": f"房间 {room_name} 创建成功"}


# 在 app.py 中添加以下类和接口

class DistanceChatRequest(BaseModel):
    user_x: int
    user_y: int
    message: str
    role_name: str
    room_name: str = "main"

class RoleDistanceResponse(BaseModel):
    role_name: str
    distance: float
    message_received: str
    message_type: str  # "clear", "muffled", "whisper"

@app.post("/distance_chat")
def distance_chat(req: DistanceChatRequest):
    """基于距离的聊天功能 - 带AI回复（考虑休息状态）"""
    try:
        room = get_room(req.room_name)
        distance_tiers = room.get_roles_by_distance_tiers(req.user_x, req.user_y)
        
        results = []
        
        # 处理近距离角色
        for role in distance_tiers["very_close"]:
            if role["name"] != "user":
                # 🔥 检查角色是否在休息
                if rest_manager.is_resting(role["name"]):
                    rest_info = rest_manager.get_rest_info(role["name"])
                    results.append({
                        "role_name": role["name"],
                        "distance": room.calculate_distance(req.user_x, req.user_y, role["x"], role["y"]),
                        "message_received": req.message,
                        "message_type": "resting",
                        "ai_reply": f"{role['name']}正在{rest_info.get('rest_type', '休息')}，没有回应",
                        "is_resting": True
                    })
                    continue
                
                hearing_memory = f"{req.role_name}: {req.message}"
                add_memory(role["name"], hearing_memory, mtype="hearing")
                
                mems = query_memory(role["name"], req.message, top_k=100000)
                prompt = build_prompt(f"回应这句话: {req.message}", mems)
                ai_reply = run_ollama_sync(prompt)
                
                add_memory(role["name"], f"我回应了: {ai_reply}", mtype="response")
                
                results.append({
                    "role_name": role["name"],
                    "distance": room.calculate_distance(req.user_x, req.user_y, role["x"], role["y"]),
                    "message_received": req.message,
                    "message_type": "clear",
                    "ai_reply": ai_reply,
                    "is_resting": False
                })
        
        # 处理中距离角色（能模糊听到）
        for role in distance_tiers["close"]:
            if role["name"] != "user":
                # 模糊处理消息
                muffled_message = f"听到有人在说话，但听不清内容"
                add_memory(role["name"], muffled_message, mtype="hearing")
                
                # 生成基于模糊信息的回复
                mems = query_memory(role["name"], "听到附近有声音", top_k=100)
                prompt = build_prompt(f"你听到附近有模糊的声音，你会说什么？", mems)
                ai_reply = run_ollama_sync(prompt)
                
                # 保存回复到记忆
                add_memory(role["name"], f"我对模糊声音的回应: {ai_reply}", mtype="response")
                
                results.append({
                    "role_name": role["name"],
                    "distance": room.calculate_distance(req.user_x, req.user_y, role["x"], role["y"]),
                    "message_received": muffled_message,
                    "message_type": "muffled",
                    "ai_reply": ai_reply
                })
        
        # 处理远距离角色（只能偶尔听到）
        for role in distance_tiers["far"]:
            if role["name"] != "user":
                # 只有重要内容才传递
                if len(req.message) > 10:  # 长消息才传递
                    whisper_message = f"隐约听到有声音"
                    add_memory(role["name"], whisper_message, mtype="hearing")
                    
                    # 生成基于隐约声音的回复
                    mems = query_memory(role["name"], "隐约听到声音", top_k=10)
                    prompt = build_prompt(f"你隐约听到远处有声音，你会说什么？", mems)
                    ai_reply = run_ollama_sync(prompt)
                    
                    # 保存回复到记忆
                    add_memory(role["name"], f"我对隐约声音的回应: {ai_reply}", mtype="response")
                    
                    results.append({
                        "role_name": role["name"],
                        "distance": room.calculate_distance(req.user_x, req.user_y, role["x"], role["y"]),
                        "message_received": whisper_message,
                        "message_type": "whisper",
                        "ai_reply": ai_reply
                    })
        
        return JSONResponse({
            "status": "success",
            "message": "消息已发送",
            "results": results,
            "total_receivers": len(results)
        })
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"发送消息失败: {str(e)}")

@app.get("/nearby_roles/{room_name}")
def get_nearby_roles(room_name: str, user_x: int, user_y: int, max_distance: int = 300):
    """获取附近的角色"""
    try:
        room = get_room(room_name)
        nearby_roles = room.get_nearby_roles(user_x, user_y, max_distance)
        return JSONResponse({
            "room_name": room_name,
            "user_position": {"x": user_x, "y": user_y},
            "nearby_roles": nearby_roles,
            "count": len(nearby_roles)
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取附近角色失败: {str(e)}")




# 一个专门查看 ChromaDB 数据的页面

class MemoryItem(BaseModel):
    id: str
    content: str
    type: str

class RoleMemoryResponse(BaseModel):
    role: str
    memories: List[MemoryItem]
    count: int

@app.get("/chromadb", response_class=HTMLResponse)
def chromadb_viewer(request: Request):
    """ChromaDB 查看器页面"""
    roles = list_roles()
    return templates.TemplateResponse("chromadb_viewer.html", {"request": request, "roles": roles})

@app.get("/api/roles")
def api_get_roles():
    """获取所有角色列表"""
    return {"roles": list_roles()}

@app.get("/api/role/{role_name}/memories")
def api_get_role_memories(role_name: str, limit: int = 50):
    """获取指定角色的所有记忆"""
    try:
        # 查询角色的所有记忆
        memories = query_memory(role_name, "", top_k=100000)
        
        # 格式化记忆数据
        formatted_memories = []
        for mem in memories:
            formatted_memories.append({
                "content": mem["content"],
                "type": mem["metadata"]["type"],
                "length": len(mem["content"])
            })
        
        return JSONResponse({
            "role": role_name,
            "memories": formatted_memories,
            "count": len(formatted_memories)
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取记忆失败: {str(e)}")

@app.delete("/api/role/{role_name}/memories")
def api_clear_role_memories(role_name: str):
    """清空指定角色的记忆"""
    try:
        if delete_collection(role_name):
            return JSONResponse({"status": "success", "message": f"角色 {role_name} 的记忆已清空"})
        else:
            raise HTTPException(status_code=500, detail="清除记忆失败")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"清除记忆失败: {str(e)}")

@app.get("/api/stats")
def api_get_stats():
    """获取 ChromaDB 统计信息"""
    try:
        roles = list_roles()
        stats = []
        total_memories = 0
        
        for role_name in roles:
            try:
                memories = query_memory(role_name, "", top_k=100000)
                count = len(memories)
                stats.append({
                    "role": role_name,
                    "count": count
                })
                total_memories += count
            except:
                stats.append({
                    "role": role_name,
                    "count": 0
                })
        
        return JSONResponse({
            "total_roles": len(roles),
            "total_memories": total_memories,
            "roles_stats": stats
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"获取统计信息失败: {str(e)}")
